<?php

add_action( 'admin_init', 'kobita_extra_compatibility' );

function kobita_extra_compatibility() {

	if ( is_admin() && current_user_can( 'activate_plugins' ) && !kobita_extra_is_theme_active() ) {

		add_action( 'admin_notices', 'kobita_extra_compatibility_notice' );

		deactivate_plugins( KOBITA_EXTRA_BASENAME );

		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}
	}
}

function kobita_extra_compatibility_notice() {
	echo '<div class="notice notice-warning"><p><strong>Note:</strong> Kobita Extra plugin has been deactivated as it requires Kobita Theme to be active.</p></div>';
}

function kobita_extra_is_theme_active() {
	return defined( 'KOBITA_THEME_VERSION' );
}

function extra_sort_option_items( $items, $selected, $field = 'term_id' ) {
	
	if ( empty( $selected ) ) {
		return $items;
	}

	$new_items = array();
	$temp_items = array();
	$temp_items_ids = array();

	foreach ( $selected as $selected_item_id ) {

		foreach ( $items as $item ) {
			if ( $selected_item_id == $item->$field ) {
				$new_items[] = $item;
			} else {
				if ( !in_array( $item->$field, $selected ) && !in_array( $item->$field, $temp_items_ids ) ) {
					$temp_items[] = $item;
					$temp_items_ids[] = $item->$field;
				}
			}
		}

	}

	$new_items = array_merge( $new_items, $temp_items );

	return $new_items;
}