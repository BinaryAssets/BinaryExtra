(function($) {

    $(document).ready(function() {

        kobita_opt_sortable();

        $(document).on('widget-added', function(e) {
            kobita_opt_sortable();


        });

        $(document).on('widget-updated', function(e) {
            kobita_opt_sortable();

        });


        /* Make some options sortable */
        function kobita_opt_sortable() {
            $(".kobita-widget-content-sortable").sortable({
                revert: false,
                cursor: "move"
            });
        }


    });

})(jQuery);